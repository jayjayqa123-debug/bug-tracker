# Bug Tracker Board (Android / iOS / Web)

A Trello-style bug tracking board with QA/Dev login, priority & severity tags,
auto-filled "Filed By", shareable ticket links, and a Zentao-style daily export.

## What's included
- **Backend:** Node.js + Express (`server.js`, `routes/`, `middleware/`)
- **Database:** real MySQL (`db/pool.js` + `db/schema.sql`) — built for cPanel's
  "MySQL® Databases" tool, so your data lives in an actual database you can
  browse in phpMyAdmin.
- **Frontend:** plain HTML/CSS/JS (`public/`) — no build step, no framework required.

## Features mapped to your request
- Separate boards per platform (Android / iOS / Web) via the tabs at the top.
- Columns: On Filing → Filed Ticket List → Filed Ticket List for Host (hidden
  automatically on the Web board, shown on Android/iOS) → Working in Progress
  by Dev → Complete (For Retest) → Reactive → Backend Issue → Closed.
- Every card has Priority and Severity as colored tag buttons, an Assignee
  (Dev) dropdown, and a "Filed By" field that is filled automatically from
  whichever QA member is logged in (never typed manually).
- Sign in / Register page: choosing "QA" or "Developer" at registration
  automatically categorizes the account. Only QA accounts can file new
  tickets; Dev accounts can be assigned to tickets and move cards.
- Each card has a 🔗 Share button that copies a public, read-only link
  (`share.html?token=...`) anyone can open without logging in.
- Export CSV button + a live stats bar showing: Filed Today, Fixed Today,
  Still Active, Closed Today, Pending Regression — the same numbers a
  Zentao-style daily bug report needs.

- **Ticket numbers:** every ticket gets an automatic number per platform
  (`AND-0001`, `IOS-0001`, `WEB-0001`, ...). It is shown in the new-ticket form,
  on the card, on the shared link, and as the first column of the CSV export.
- **Sign in / Sign up with Google or manually** (email + password). First-time
  Google users choose QA or Developer (+ platform) once, then go straight in
  next time.

---

## Updating an existing install
Just replace the files, run `npm install`, and restart. On every start the app
checks the database and upgrades it automatically (adds the new columns, and
numbers your existing tickets in the order they were created). You do not need
to run any SQL. To run the upgrade without starting the site: `npm run migrate`.

---

## Google sign-in setup (optional)
Manual sign-in works without this. To show the "Continue with Google" button:

1. Go to https://console.cloud.google.com and create (or pick) a project.
2. Open **APIs & Services > OAuth consent screen**, choose **External**, fill in
   the app name and your email, and save.
3. Open **APIs & Services > Credentials > Create credentials > OAuth client ID**.
   Application type: **Web application**.
4. Under **Authorized JavaScript origins** add every address you open the site
   from, for example:
   - `http://localhost:3000` (local testing)
   - `https://bugs.yourdomain.com` (your live cPanel address)
   Leave "Authorized redirect URIs" empty.
5. Click **Create** and copy the **Client ID** (ends in
   `.apps.googleusercontent.com`).
6. Paste it into `.env` as `GOOGLE_CLIENT_ID=...` (locally), and add the same
   `GOOGLE_CLIENT_ID` under Environment Variables in cPanel's Setup Node.js App.
   Restart the app.

Notes:
- Open the site in a normal browser (Chrome/Edge) at `http://localhost:3000`.
  Google blocks sign-in inside embedded browsers such as VS Code's built-in
  Simple Browser.
- While the consent screen is in "Testing" mode, add your teammates' Gmail
  addresses under **Test users**, or click **Publish app** so anyone can sign in.
- If someone already registered manually and later uses Google with the same
  email, the two are linked to the same account.

---

## Part 1 — Run it locally in VS Code (using a local MySQL)

1. **Unzip** the project and open the `bugtracker` folder in VS Code
   (`File > Open Folder...`).

2. **Install Node.js** if you don't have it: https://nodejs.org (LTS version).
   Check it's installed in VS Code's terminal (`Terminal > New Terminal`):
   ```
   node -v
   npm -v
   ```

3. **Install MySQL locally** if you don't already have it (e.g. MySQL
   Community Server, XAMPP, or MAMP all include it). Make sure it's running.

4. **Create the database** — open a MySQL client (MySQL Workbench, the
   `mysql` CLI, or phpMyAdmin if you're using XAMPP) and run:
   ```sql
   CREATE DATABASE bugtracker;
   CREATE USER 'btuser'@'localhost' IDENTIFIED BY 'btpass123';
   GRANT ALL PRIVILEGES ON bugtracker.* TO 'btuser'@'localhost';
   FLUSH PRIVILEGES;
   ```
   Then import the schema:
   ```
   mysql -u btuser -p bugtracker < db/schema.sql
   ```

5. **Install dependencies** — in the VS Code terminal, inside the
   `bugtracker` folder:
   ```
   npm install
   ```

6. **Create your environment file:**
   ```
   cp .env.example .env
   ```
   (Windows Command Prompt: `copy .env.example .env`.)
   Open `.env` and set `JWT_SECRET` to any long random string, and make sure
   `DB_USER` / `DB_PASSWORD` / `DB_NAME` match what you created in step 4.

7. **Run the server:**
   ```
   npm start
   ```
   You should see: `Bug Tracker running at http://localhost:3000`

8. **Open the app** at `http://localhost:3000`.
   - Click **Register**, create one account with role **QA** and another
     with role **Dev**.
   - Sign in as QA, click **+ File Ticket**, fill it in — it appears on the
     board. Drag cards between columns, or open a card and use the Status
     dropdown.
   - Click 🔗 **Share** on any card to copy its public link.
   - Click **Export CSV** to download the bug list for the selected
     platform tab.

---

## Part 2 — Deploying on your cPanel (PHP/MySQL + Node.js App support)

Your cPanel has both **MySQL® Databases** and a **Setup Node.js App** tool —
that's exactly what this app needs. Here's the full path:

### Step 1: Upload the files
1. In cPanel, open **File Manager** (or use FTP/SFTP).
2. Create a folder for the app outside `public_html`, e.g.
   `/home/yourcpaneluser/bugtracker` (Node apps on cPanel are usually kept
   outside the public web root; the Node.js App tool maps a URL to it for you).
3. Upload the whole `bugtracker` folder's contents there (you can upload the
   zip and use File Manager's "Extract" feature).

### Step 2: Create the MySQL database
1. In cPanel, open **MySQL® Databases**.
2. Under "Create New Database", name it something like `bugtracker` — cPanel
   will prefix it automatically, e.g. `yourcpaneluser_bugtracker`.
3. Under "MySQL Users", create a user (e.g. `btuser` → becomes
   `yourcpaneluser_btuser`) with a strong password.
4. Under "Add User To Database", add that user to the database and grant
   **ALL PRIVILEGES**.
5. Open **phpMyAdmin** from cPanel, select your new database, click the
   **Import** tab, and upload `db/schema.sql` from this project. This
   creates the `users` and `tickets` tables.

### Step 3: Set up the Node.js App
1. In cPanel, open **Setup Node.js App** and click **Create Application**.
2. **Node.js version:** pick the latest available (18 or newer).
3. **Application mode:** Production.
4. **Application root:** the folder path you uploaded to (e.g.
   `bugtracker`).
5. **Application URL:** the domain/subdomain you want this on (e.g.
   `bugs.yourdomain.com`).
6. **Application startup file:** `server.js`.
7. Click **Create**.
8. On the app's page, scroll to **Environment Variables** and add:
   - `JWT_SECRET` = a long random string
   - `DB_HOST` = `localhost`
   - `DB_PORT` = `3306`
   - `DB_NAME` = the full prefixed database name (e.g. `yourcpaneluser_bugtracker`)
   - `DB_USER` = the full prefixed username (e.g. `yourcpaneluser_btuser`)
   - `DB_PASSWORD` = the password you set in Step 2
   - (cPanel manages `PORT` itself for Node apps — you don't need to set it.)
9. Click **Run NPM Install** on the same page (this reads `package.json` and
   installs Express, mysql2, bcryptjs, etc. on the server).
10. Click **Restart** (or **Start**) to launch the app.
11. Visit your Application URL — you should see the Sign In page.

### Notes for cPanel
- If your cPanel account only allows Node apps *inside* `public_html`, that's
  fine too — cPanel's Node.js App tool still proxies the URL correctly either way.
- Don't run `npm start` manually over SSH for a cPanel Node app — always use
  the panel's Start/Restart buttons, since cPanel manages the process (via
  Passenger) and injects the correct `PORT` for you.
- If you ever need to update the code, re-upload the changed files, click
  **Run NPM Install** again if `package.json` changed, then **Restart**.

---

## Project structure
```
bugtracker/
  server.js              Express app entrypoint
  routes/auth.js          Register / Login (assigns QA or Dev role)
  routes/tickets.js       Create/list/update/move/delete tickets, share link
  routes/export.js        CSV export + daily stats
  middleware/auth.js       JWT verification
  db/pool.js                MySQL connection pool (reads DB_* from .env)
  db/migrate.js             Creates/upgrades tables automatically on startup
  db/ticketNumber.js        AND-0001 / IOS-0001 / WEB-0001 generator
  services/google.js        Verifies Google sign-in tokens
  db/schema.sql              Table definitions - import this in phpMyAdmin
  public/index.html        Sign in / Register page
  public/board.html        The Trello-style board
  public/share.html         Public read-only ticket view
  public/js/auth.js         Login/register logic
  public/js/board.js         Board rendering, drag & drop, modal, export
  public/css/style.css       Styling
```

## Notes
- Passwords are hashed with bcrypt — never stored in plain text.
- Login sessions use JWT tokens valid for 7 days, stored in the browser's
  localStorage.
- This was tested end-to-end against a real MySQL/MariaDB database
  (register, login, file/move/close tickets, share links, stats, and CSV
  export) before being sent to you.

## Attachments (links, images, videos)

In the ticket form, the **Attachments** row has three buttons: **🔗 Link**, **🖼 Image** and **🎥 Video**.

- While filing a new ticket, attachments are queued and uploaded right after the ticket is saved.
- On a saved ticket, they upload immediately and can be removed with the ✕ button.
- Images: JPG, PNG, GIF, WEBP (max 10 MB). Videos: MP4, WEBM, MOV, OGV (max 100 MB). Links: http/https only.
- Files are stored in the `uploads/` folder (created automatically, git-ignored) and shown on the shared ticket page too.
  Keep `uploads/` when you redeploy, and make sure your host allows request bodies up to 100 MB.
- The new `attachments` table is created automatically on startup (no manual migration needed).
